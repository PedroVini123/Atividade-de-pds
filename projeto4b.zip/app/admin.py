from django.contrib import admin
from .models import Autor, Tag, Reportagem


class AutorAdmin(admin.ModelAdmin):
    fields = ("nome",)


class TagAdmin(admin.ModelAdmin):
    fields = ("nome",)


class ReportagemAdmin(admin.ModelAdmin):
    fields = (
        "titulo",
        "descricao",
        "autor",
        "data",
        "tags",
        "img",
        "conteudo",
        "destacada",
    )


admin.site.register(Autor, AutorAdmin)
admin.site.register(Tag, TagAdmin)
admin.site.register(Reportagem, ReportagemAdmin)
